package jogo;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Jogo {
	private ArrayList<ArrayList<Celula>> tabuleiro;
	private ArrayList<Peao> peoes;
	//private Scanner sc;
	private String vencedor;
	
	
	public Jogo() {
		
		peoes = new ArrayList<>();
		//sc = new Scanner(System.in);
		vencedor = null;
	}
	
	
	public void iniciarJogo() {
		
		for(int i =0; i < 4; i++) {
			Peao auxiliar = new Peao("Vermelho", 0, 0);
			peoes.add(auxiliar);
		}
		
		for(int i =0; i < 4; i++) {
			Peao auxiliar = new Peao("Azul", 0, 0);
			peoes.add(auxiliar);
		}
		ArrayList<Celula> celulas1 = new ArrayList<>();
		ArrayList<Celula> celulas2 = new ArrayList<>();
		ArrayList<Celula> celulas3 = new ArrayList<>();
		ArrayList<Celula> celulas4 = new ArrayList<>();
		tabuleiro = new ArrayList<>();
		tabuleiro.add(celulas1);
		tabuleiro.add(celulas2);
		tabuleiro.add(celulas3);
		tabuleiro.add(celulas4);
		
		for(int j = 0; j < 14; j++) {
			Celula auxiliar = new Celula(j);
			celulas1.add(auxiliar);
		}
		
		for(int j = 0; j < 14; j++) {
			Celula auxiliar = new Celula(j);
			celulas2.add(auxiliar);
		}
		
		for(int j = 0; j < 14; j++) {
			Celula auxiliar = new Celula(j);
			celulas3.add(auxiliar);
		}
		
		for(int j = 0; j < 14; j++) {
			Celula auxiliar = new Celula(j);
			celulas4.add(auxiliar);
		}
		
		for( int i = 0; i < 8; i++) {
			tabuleiro.get(0).get(0).addPeao( peoes.get(i));
		}
		
	}
	
	public int rolarDado() {
		Random dado = new Random();
		return dado.nextInt(6) + 1;
	}
	
	public void verificaMovimentarPeca(int index) {
		if( !(peoes.get(index).getLinha() == 3 && peoes.get(index).getColuna() == 13) ) {
			int movimento = rolarDado();
			System.out.println("Peao [" + index + "] rolou [" + movimento + "]");
			
			if( (peoes.get(index).getColuna() + movimento > 13)  && (peoes.get(index).getLinha() + 1 < 4 ) ) {
				if(tabuleiro.get( peoes.get(index).getLinha() + 1 ).get( peoes.get(index).getColuna() + movimento - 14 ).verificaPeao(peoes.get(index))) {
					mover(peoes.get(index).getLinha() + 1, peoes.get(index).getColuna() + movimento - 14, peoes.get(index));
				} else {
					zerarPosicao(peoes.get(index));
				}
			} else if ( (peoes.get(index).getColuna() + movimento > 13) && (peoes.get(index).getLinha() + 1 == 4 ) ) {
				if(tabuleiro.get(3).get(13).verificaPeao(peoes.get(index))) {
					mover(3, 13, peoes.get(index));
				} else {
					zerarPosicao(peoes.get(index));
				}
			} else {
				if(tabuleiro.get( peoes.get(index).getLinha() ).get( peoes.get(index).getColuna() + movimento ).verificaPeao(peoes.get(index))) {
					mover(peoes.get(index).getLinha(), peoes.get(index).getColuna() + movimento, peoes.get(index));
				} else {
					zerarPosicao(peoes.get(index));
				}
			}
			mostrarTabuleiro();
		}
	}
	
	public void mover(int linha, int coluna, Peao peao) {
		if(tabuleiro.get( peao.getLinha() ).get( peao.getColuna() ).removePeao(peao) ) {
			System.out.println("Removou");
			peao.setLinha(linha);
			peao.setColuna(coluna);
		}
		
	}
	
	public void zerarPosicao(Peao peao) {
		peao.setLinha(0);
		peao.setColuna(0);
		tabuleiro.get(0).get(0).addPeao(peao);
	}
	
	public void mostrarTabuleiro() {
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 14; j++) {
				System.out.printf(" %5s", tabuleiro.get(i).get(j).getPeoes().size());
			}
			System.out.println();
		}
		for( int i = 0; i < 8; i++) {
			System.out.println("Peao [" + i + "] esta na posicao [" + peoes.get(i).getLinha() + "][" + peoes.get(i).getColuna() + "]");
		}
		
	}
	
	public boolean fimDeJogo() {
		if(tabuleiro.get(3).get(13).getPeoes().size() == 4) {
			vencedor = tabuleiro.get(3).get(13).getPeoes().get(0).getCor();
			return true;
		}
		return false;
	}
	
	/**
	 * @return the vencedor
	 */
	public String getVencedor() {
		return vencedor;
	}
	
	
	
	
}
