package jogo;

public class Jogar {

	public static void main(String[] args) {
		Jogo jogo = new Jogo();
		jogo.iniciarJogo();
		int cont = 0;
		jogo.mostrarTabuleiro();
		while(!jogo.fimDeJogo()) {
			if(cont == 8)
				cont = 0;
			System.out.println();
			jogo.verificaMovimentarPeca(cont);
			cont++;
		}
		
		System.out.println("\n\n!!!!Parabens vencedor do jogo: [" + jogo.getVencedor() + "]!!!!");
	}
}